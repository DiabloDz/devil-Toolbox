#!/usr/bin/perl

use if $^O eq "MSWin32", Win32::Console::ANSI;
use Getopt::Long;
use HTTP::Request;
use LWP::UserAgent;
use IO::Select;
use HTTP::Cookies;
use HTTP::Response;
use Term::ANSIColor;
use HTTP::Request::Common qw(POST);
use HTTP::Request::Common qw(GET);
use URI::URL;
use IO::Socket::INET;
my $ua = LWP::UserAgent->new;
$ua->timeout(10);

my $datetime    = localtime;

@months = qw(01 02 03 04 05 06 07 08 09 10 11 12);
($second, $minute, $hour, $dayOfMonth, $month, $yearOffset, $dayOfWeek, $dayOfYear, $daylightSavings) = localtime();
$year = 1900 + $yearOffset;
$month = "$months[$month]";

sub banner() {
system("[Dzx] CMSFILTER");
if ($^O =~ /MSWin32/) {system("cls"); }else { system("clear"); }
print color('bold green');
print q(

                              ...
           s,                .                    .s
            ss,              . ..               .ss
            'SsSs,           ..  .           .sSsS'
             sSs'sSs,        .   .        .sSs'sSs
              sSs  'sSs,      ...      .sSs'  sSs
               sS,    'sSs,         .sSs'    .Ss
               'Ss       'sSs,   .sSs'       sS'
      ...       sSs         ' .sSs'         sSs       ...
     .           sSs       .sSs' ..,       sSs       .
     . ..         sS,   .sSs'  .  'sSs,   .Ss        . ..
     ..  .        'Ss .Ss'     .     'sSs. ''        ..  .
     .   .         sSs '       .        'sSs,        .   .
      ...      .sS.'sSs        .        .. 'sSs,      ...
            .sSs'    sS,     .....     .Ss    'sSs,
         .sSs'       'Ss       .       sS'       'sSs,
      .sSs'           sSs      .      sSs           'sSs,
   .sSs'____________________________ sSs ______________'sSs,
.sSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS'.Ss SSSSSSSSSSSSSSSSSSSSSs,
                        ...         sS'
                         sSs       sSs
                          sSs     sSs       - Diablo.Dz CMSFILTER -
                           sS,   .Ss
author : Diablo.Dz         'Ss   sS'
Help : Fb.com/mahrez.benx   sSs sSs
                             sSsSs
                              sSs
                               s

);

print color('reset');
print "                       ";
print colored ("[ Start At $datetime ]",'white on_black'),"\n\n";
}
banner();
GetOptions(

);


{
print color('bold red'),"  [ ";
print color('bold green'),"Dzx";
print color('black'), "] ";
print color("black"),"name websites list : ";
$list=<STDIN>;
chomp $list;
}
$a = 0;
open (THETARGET, "<../$list") || die "[-] Can't open the list websites file";
@TARGETS = <THETARGET>;
close THETARGET;
$link=$#TARGETS + 1;

banner();
print color("black"), "[ Dzx ] Sites count >  : ";
print color("bold red"), "".scalar(@TARGETS)."\n\n\n";
print color('reset');

OUTER: foreach $site(@TARGETS){
chomp($site);
$a++;
cms();
}
################ CMS DETCTER #####################
sub cms(){
$ua = LWP::UserAgent->new(keep_alive => 1);
$ua->agent("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31");
$ua->timeout (15);
$lokomedia = "$site/smiley/1.gif";
my $lokomediacms = $ua->get("$lokomedia")->content_type;
$loko = "$site/rss.xml";
my $lokomediacmstow = $ua->get("$loko")->content;
my $cms = $ua->get("$site")->content;

if($cms =~/<script type=\"text\/javascript\" src=\"\/media\/system\/js\/mootools.js\"><\/script>| \/media\/system\/js\/|com_content|Joomla!/) {
    print color('black'),"[$a] $site - ";
    print color("bold green"), "Joomla\n\n";
    print color('reset');
    open(save, '>>../joomla.txt');
    print save "$site\n";
    close(save);
  comjce();
  comedia();
  comjdownloads();
  comjdownloadsdef();
  comfabrik();
  comfabrikdef();
  comfabrik2();
  comfabrikdef2();
  comadsmanager();
  comusers();
  comweblinks();
  comjbcatalog();
  foxcontact();
  sexycontactform();
  comblog();
  comrokdownloads();
  extplorer();
  comjwallpapers();
  com_facileforms();
  mod_simplefileupload();
}elsif($cms =~/wp-content|wordpress|xmlrpc.php/) {
    print color('black'),"[$a] $site - ";
    print color("bold green"), "WordPress\n\n";
    print color('reset');
    open(save, '>>../Wordpress.txt');
    print save "$site\n";
    close(save);
    addblockblocker();
    blaze();
    catpro();
    cherry();
    downloadsmanager();
    formcraft();
    levoslideshow();
    powerzoomer();
    gravityforms();
    revslider();
    getconfig();
    showbiz();
    ads();
    slideshowpro();
    wpmobiledetector();
    wysija();
    inboundiomarketing();
    dzszoomsounds();
    reflexgallery();
    sexycontactform();
    wtffu();
    wpjm();
    phpeventcalendar();
    synoptic();
    Wpshop();
    cubed();
    RightNow();
    konzept();
    omnisecurefiles();
    pitchprint();
    satoshi();
    pinboard();
    barclaycart();
    wpinjection();
}elsif($cms =~/Drupal|drupal|sites\/all|drupal.org/) {
    print color('black'),"[$a] $site - ";
    print color("bold green"), "DruPal\n\n";
    print color('reset');
    open(save, '>>../drupal.txt');
    print save "$site\n";
    close(save);
drupal();
drupalgeddon();
}elsif($cms =~/Prestashop|prestashop/) {
    print color('black'),"[$a] $site - ";
    print color("bold green"), "Prestashop\n\n";
    print color('reset');
    open(save, '>>../Prestashop.txt');
    print save "$site\n";
    close(save);
columnadverts();
soopamobile();
soopabanners();
vtermslideshow();
simpleslideshow();
productpageadverts();
homepageadvertise();
homepageadvertise2();
jro_homepageadvertise();
attributewizardpro();
oneattributewizardpro();
attributewizardproOLD();
attributewizardpro_x();
advancedslider();
cartabandonmentpro();
cartabandonmentproOld();
videostab();
wg24themeadministration();
fieldvmegamenu();
wdoptionpanel();
pk_flexmenu();
pk_vertflexmenu();
nvn_export_orders();
megamenu();
blocktestimonial();
tdpsthemeoptionpanel();
psmodthemeoptionpanel();
masseditproduct();
}elsif($lokomediacms =~/image\/gif/) {
print color('black'),"[$a] $site - ";
    print color("red"), "Lokomedia\n\n";
    print color('reset');
    open(save, '>>../lokomedia.txt');
    print save "$site\n";
    close(save);
    lokomedia();
}elsif($lokomediacmstow =~/lokomedia/) {
print color('black'),"[$a] $site - ";
    print color("red"), "Lokomedia\n\n";
    print color('reset');
    open(save, '>>../lokomedia.txt');
    print save "$site\n";
    close(save);
    lokomedia();
}else{
print color('black'),"[$a] $site - ";
    print color("bold green"), "Unknown\n\n";
    open(save, '>>../Unknown.txt');
    print color('reset');
    print save "$site\n";
    close(save);
}
}
